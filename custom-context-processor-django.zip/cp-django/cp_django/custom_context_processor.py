from cp_app.models import *

def service_list(request):
    return {
        'all_services': service_model.objects.all()
        }
